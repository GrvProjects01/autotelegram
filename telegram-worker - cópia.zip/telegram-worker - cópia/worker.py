import os
import re
import asyncio
import httpx

from telethon import TelegramClient, events
from dotenv import load_dotenv


# ==========================================
# CARREGAR VARIÁVEIS DE AMBIENTE
# ==========================================

load_dotenv()

API_ID = int(os.environ["TELEGRAM_API_ID"])
API_HASH = os.environ["TELEGRAM_API_HASH"]

LOVABLE_API_URL = os.environ["LOVABLE_API_URL"].rstrip("/")
WORKER_SECRET = os.environ["LOVABLE_WORKER_SECRET"]

SESSION_NAME = os.getenv(
    "TELEGRAM_SESSION_NAME",
    "telegram_main"
)


# ==========================================
# CLIENTE TELEGRAM
# ==========================================

client = TelegramClient(
    SESSION_NAME,
    API_ID,
    API_HASH
)


# ==========================================
# ENDPOINTS LOVABLE
# ==========================================

AUTOMATIONS_ENDPOINT = "/api/public/worker/automations"
LOGS_ENDPOINT = "/api/public/worker/logs"
HEARTBEAT_ENDPOINT = "/api/public/worker/heartbeat"


# ==========================================
# REQUEST PARA LOVABLE
# ==========================================

async def lovable_request(
    path,
    method="GET",
    data=None
):
    headers = {
        "x-worker-secret": WORKER_SECRET,
        "Content-Type": "application/json"
    }

    url = f"{LOVABLE_API_URL}{path}"

    async with httpx.AsyncClient(timeout=30) as http:

        try:

            if method == "POST":
                response = await http.post(
                    url,
                    json=data,
                    headers=headers
                )

            else:
                response = await http.get(
                    url,
                    headers=headers
                )

            response.raise_for_status()

            return response.json()

        except httpx.HTTPStatusError as error:

            status = error.response.status_code

            print(f"[Lovable] HTTP {status}")
            print(f"[Lovable] URL: {url}")

            try:
                print(
                    "[Lovable] Resposta:",
                    error.response.text
                )
            except Exception:
                pass

            raise

        except httpx.RequestError as error:

            print(
                "[Lovable] Erro de conexão:",
                str(error)
            )

            raise


# ==========================================
# BUSCAR AUTOMAÇÕES
# ==========================================

async def load_automations():

    result = await lovable_request(
        AUTOMATIONS_ENDPOINT
    )

    automations = result.get(
        "automations",
        []
    )

    return automations


# ==========================================
# PROCESSAMENTO DE TEXTO
# ==========================================

async def process_text(
    text,
    automation
):

    if text is None:
        text = ""

    result = text


    # --------------------------------------
    # BLACKLIST
    # --------------------------------------

    blacklist = automation.get(
        "blacklist",
        []
    )

    for rule in blacklist:

        if not rule.get(
            "enabled",
            True
        ):
            continue

        term = rule.get(
            "term",
            ""
        )

        if not term:
            continue

        match_type = rule.get(
            "match_type",
            "contains"
        )

        action = rule.get(
            "action",
            "block"
        )

        replacement = rule.get(
            "replacement",
            ""
        )

        detected = False


        # CONTAINS

        if match_type == "contains":

            detected = (
                term.lower()
                in
                result.lower()
            )


        # EXACT

        elif match_type == "exact":

            detected = (
                result.lower().strip()
                ==
                term.lower().strip()
            )


        # REGEX

        elif match_type == "regex":

            try:

                detected = bool(
                    re.search(
                        term,
                        result,
                        flags=re.IGNORECASE
                    )
                )

            except re.error:

                print(
                    f"[Blacklist] Regex inválida: {term}"
                )

                continue


        # ----------------------------------
        # AÇÃO
        # ----------------------------------

        if detected:

            if action == "block":

                return None


            elif action == "remove":

                if match_type == "regex":

                    result = re.sub(
                        term,
                        "",
                        result,
                        flags=re.IGNORECASE
                    )

                else:

                    result = re.sub(
                        re.escape(term),
                        "",
                        result,
                        flags=re.IGNORECASE
                    )


            elif action == "replace":

                if match_type == "regex":

                    result = re.sub(
                        term,
                        replacement,
                        result,
                        flags=re.IGNORECASE
                    )

                else:

                    result = re.sub(
                        re.escape(term),
                        replacement,
                        result,
                        flags=re.IGNORECASE
                    )


    # --------------------------------------
    # REPLACEMENTS
    # --------------------------------------

    replacements = automation.get(
        "replacements",
        []
    )

    replacements = sorted(
        replacements,
        key=lambda x: x.get(
            "priority",
            0
        )
    )

    for rule in replacements:

        if not rule.get(
            "enabled",
            True
        ):
            continue

        find = rule.get(
            "match",
            ""
        )

        replacement = rule.get(
            "replacement",
            ""
        )

        if not find:
            continue

        case_sensitive = rule.get(
            "case_sensitive",
            True
        )


        if case_sensitive:

            result = result.replace(
                find,
                replacement
            )

        else:

            result = re.sub(
                re.escape(find),
                replacement,
                result,
                flags=re.IGNORECASE
            )


    # --------------------------------------
    # PREFIXO
    # --------------------------------------

    prefix = automation.get(
        "prefix_text"
    )

    if prefix:

        if result:

            result = (
                prefix
                + "\n\n"
                + result
            )

        else:

            result = prefix


    # --------------------------------------
    # RODAPÉ
    # --------------------------------------

    footer = automation.get(
        "footer_text"
    )

    if footer:

        if result:

            result = (
                result
                + "\n\n"
                + footer
            )

        else:

            result = footer


    return result


# ==========================================
# ENVIAR LOG PARA LOVABLE
# ==========================================

async def send_log(
    automation_id,
    source_message_id,
    status,
    original_text="",
    processed_text="",
    destination_message_id=None,
    blocked_reason=None,
    error_message=None
):

    payload = {

        "automation_id":
            automation_id,

        "source_message_id":
            source_message_id,

        "destination_message_id":
            destination_message_id,

        "original_text":
            original_text,

        "processed_text":
            processed_text,

        "status":
            status,

        "blocked_reason":
            blocked_reason,

        "error_message":
            error_message
    }


    try:

        await lovable_request(
            LOGS_ENDPOINT,
            "POST",
            payload
        )

    except Exception as error:

        print(
            "[Logs] Não foi possível "
            "registrar log:",
            str(error)
        )


# ==========================================
# PROCESSAR NOVA MENSAGEM
# ==========================================

async def handle_message(event):

    try:

        automations = await load_automations()

        source_id = event.chat_id


        print(
            f"[Telegram] Nova mensagem recebida "
            f"do chat: {source_id}"
        )


        # ----------------------------------
        # PROCURAR AUTOMAÇÃO
        # ----------------------------------

        for automation in automations:

            automation_source = automation.get(
                "source_chat_id"
            )

            if not automation_source:
                continue


            if (
                str(automation_source)
                !=
                str(source_id)
            ):

                continue


            print(
                "[Automation] "
                "Automação encontrada:",
                automation.get("id")
            )


            original_text = (
                event.message.message
                or ""
            )


            # ----------------------------------
            # PROCESSAR TEXTO
            # ----------------------------------

            processed = await process_text(
                original_text,
                automation
            )


            # ----------------------------------
            # BLACKLIST BLOQUEOU
            # ----------------------------------

            if processed is None:

                print(
                    "[Blacklist] "
                    "Mensagem bloqueada."
                )

                await send_log(

                    automation_id=
                        automation["id"],

                    source_message_id=
                        event.message.id,

                    status="blocked",

                    original_text=
                        original_text,

                    blocked_reason=
                        "blacklist"
                )

                continue


            destination = automation.get(
                "destination_chat_id"
            )


            # ----------------------------------
            # SEM DESTINO
            # ----------------------------------

            if not destination:

                print(
                    "[Automation] "
                    "Destino não configurado."
                )

                await send_log(

                    automation_id=
                        automation["id"],

                    source_message_id=
                        event.message.id,

                    status="error",

                    original_text=
                        original_text,

                    processed_text=
                        processed,

                    error_message=
                        "destination_chat_id "
                        "não configurado"
                )

                continue


            # ----------------------------------
            # REPUBLICAR
            # ----------------------------------

            try:

                preserve_media = automation.get(
                    "preserve_media",
                    True
                )


                # MENSAGEM COM MÍDIA

                if (
                    event.message.media
                    and preserve_media
                ):

                    sent_message = (
                        await client.send_file(
                            destination,
                            event.message.media,
                            caption=processed
                        )
                    )


                # MENSAGEM SOMENTE TEXTO

                else:

                    sent_message = (
                        await client.send_message(
                            destination,
                            processed
                        )
                    )


                print(
                    "[Publish] "
                    "Mensagem publicada "
                    "com sucesso."
                )


                destination_message_id = (
                    sent_message.id
                    if sent_message
                    else None
                )


                # ----------------------------------
                # LOG
                # ----------------------------------

                await send_log(

                    automation_id=
                        automation["id"],

                    source_message_id=
                        event.message.id,

                    destination_message_id=
                        destination_message_id,

                    status="published",

                    original_text=
                        original_text,

                    processed_text=
                        processed
                )


            except Exception as publish_error:

                print(
                    "[Publish] Erro:",
                    type(
                        publish_error
                    ).__name__,
                    str(
                        publish_error
                    )
                )


                await send_log(

                    automation_id=
                        automation["id"],

                    source_message_id=
                        event.message.id,

                    status="error",

                    original_text=
                        original_text,

                    processed_text=
                        processed,

                    error_message=
                        str(
                            publish_error
                        )
                )


    except Exception as error:

        print(
            "Erro processando mensagem:",
            type(error).__name__,
            str(error)
        )


# ==========================================
# EVENTO TELEGRAM
# ==========================================

@client.on(events.NewMessage)
async def new_message_handler(event):

    await handle_message(event)


# ==========================================
# HEARTBEAT
# ==========================================

async def heartbeat_loop():

    while True:

        try:

            me = await client.get_me()


            # ----------------------------------
            # NOME COMPLETO
            # ----------------------------------

            display_name = (
                f"{me.first_name or ''} "
                f"{me.last_name or ''}"
            ).strip()


            # ----------------------------------
            # PAYLOAD NOVO
            # ----------------------------------

            payload = {

                "worker_id":
                    "telegram-main",

                # ID REAL DO TELEGRAM
                "telegram_user_id":
                    str(me.id),

                # NOME REAL DA CONTA
                "telegram_display_name":
                    display_name,

                # USERNAME REAL
                "telegram_username":
                    me.username,

                "status":
                    "online",

                "version":
                    "0.3.0"
            }


            response = await lovable_request(
                HEARTBEAT_ENDPOINT,
                "POST",
                payload
            )


            print(
                "[Heartbeat] enviado."
            )


            # ----------------------------------
            # MOSTRAR UUID INTERNO SE RETORNAR
            # ----------------------------------

            telegram_account_id = (
                response.get(
                    "telegram_account_id"
                )
                if isinstance(
                    response,
                    dict
                )
                else None
            )


            if telegram_account_id:

                print(
                    "[Heartbeat] Conta Lovable:",
                    telegram_account_id
                )


        except Exception as error:

            print(
                "[Heartbeat] erro:",
                type(error).__name__,
                str(error)
            )


        # ENVIA HEARTBEAT A CADA 60s

        await asyncio.sleep(60)


# ==========================================
# MAIN
# ==========================================

async def main():

    print(
        "================================="
    )

    print(
        " TELEGRAM WORKER"
    )

    print(
        "================================="
    )


    print(
        "[Worker] Conectando "
        "ao Telegram..."
    )


    # --------------------------------------
    # CONECTAR TELEGRAM
    # --------------------------------------

    await client.start()


    me = await client.get_me()


    print(
        "[Telegram] Conectado!"
    )

    print(
        f"[Telegram] ID: {me.id}"
    )

    print(
        f"[Telegram] Nome: "
        f"{me.first_name}"
    )


    if me.username:

        print(
            f"[Telegram] Username: "
            f"@{me.username}"
        )


    # --------------------------------------
    # TESTAR LOVABLE
    # --------------------------------------

    print(
        "[Lovable] Testando API..."
    )


    try:

        automations = (
            await load_automations()
        )


        print(
            "[Lovable] Conectado!"
        )


        print(
            "[Lovable] "
            f"{len(automations)} "
            "automações ativas."
        )


    except Exception as error:

        print(
            "[Lovable] Falha "
            "na integração:"
        )

        print(
            type(error).__name__,
            str(error)
        )


    # --------------------------------------
    # INICIAR HEARTBEAT
    # --------------------------------------

    asyncio.create_task(
        heartbeat_loop()
    )


    print(
        "================================="
    )

    print(
        "[Worker] ONLINE"
    )

    print(
        "[Worker] Aguardando "
        "novas mensagens..."
    )

    print(
        "================================="
    )


    # --------------------------------------
    # MANTER CONECTADO
    # --------------------------------------

    await client.run_until_disconnected()


# ==========================================
# EXECUTAR
# ==========================================

if __name__ == "__main__":

    asyncio.run(
        main()
    )