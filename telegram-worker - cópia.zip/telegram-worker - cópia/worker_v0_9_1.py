import os
import re
import copy
import asyncio
import httpx
import time
import fcntl
import tempfile
import hashlib

from collections import defaultdict

from telethon import TelegramClient, events
from telethon.errors import ChatForwardsRestrictedError
from telethon.tl.types import (
    Channel,
    Chat,
    MessageEntityTextUrl,
)

from dotenv import load_dotenv


# ============================================================
# CONFIGURAÇÃO
# ============================================================

load_dotenv()

API_ID = int(os.environ["TELEGRAM_API_ID"])
API_HASH = os.environ["TELEGRAM_API_HASH"]

LOVABLE_API_URL = os.environ["LOVABLE_API_URL"].rstrip("/")
WORKER_SECRET = os.environ["LOVABLE_WORKER_SECRET"]

SESSION_NAME = os.getenv(
    "TELEGRAM_SESSION_NAME",
    "telegram_main"
)

WORKER_ID = os.getenv(
    "TELEGRAM_WORKER_ID",
    "telegram-main"
)

WORKER_VERSION = "0.9.1"

HEARTBEAT_INTERVAL = 60
CHAT_SYNC_INTERVAL = 15 * 60


# ============================================================
# CLIENT
# ============================================================

client = TelegramClient(
    SESSION_NAME,
    API_ID,
    API_HASH
)


# ============================================================
# CACHE
# ============================================================

ENTITY_CACHE = {}

# Cache local de vínculos.
#
# chave:
# source_chat_id:source_message_id:automation_id
#
# valor:
# lista de links.

MESSAGE_LINK_CACHE = {}


# ============================================================
# ANTI-DUPLICAÇÃO / LOCK
# ============================================================

# Impede duas execuções do mesmo Worker no mesmo Mac/servidor.
# Isso é importante porque dois processos Telethon com a mesma
# conta podem receber o mesmo update e publicar duas vezes.
PROCESS_LOCK_HANDLE = None

# Impede que dois handlers concorrentes do MESMO processo
# processem a mesma mensagem/álbum ao mesmo tempo.
PROCESSING_KEYS = set()
PROCESSING_KEYS_LOCK = asyncio.Lock()

# Cache temporal por fingerprint para impedir duplicações
# que venham de updates diferentes do Telegram para o mesmo conteúdo.
FINGERPRINT_CACHE = {}
FINGERPRINT_CACHE_LOCK = asyncio.Lock()

# Janela de deduplicação.
FINGERPRINT_TTL_SECONDS = 30


def acquire_process_lock():
    global PROCESS_LOCK_HANDLE

    safe_session = re.sub(
        r"[^a-zA-Z0-9_.-]+",
        "_",
        str(SESSION_NAME)
    )

    lock_path = os.path.join(
        tempfile.gettempdir(),
        f"{safe_session}_{WORKER_ID}.lock"
    )

    PROCESS_LOCK_HANDLE = open(
        lock_path,
        "w"
    )

    try:
        fcntl.flock(
            PROCESS_LOCK_HANDLE.fileno(),
            fcntl.LOCK_EX | fcntl.LOCK_NB
        )

        PROCESS_LOCK_HANDLE.seek(0)
        PROCESS_LOCK_HANDLE.truncate()
        PROCESS_LOCK_HANDLE.write(
            str(os.getpid())
        )
        PROCESS_LOCK_HANDLE.flush()

        print(
            "[Worker Lock] Processo exclusivo adquirido."
        )

    except BlockingIOError:
        raise RuntimeError(
            "Já existe outro Worker rodando com esta sessão "
            "neste computador/servidor. Feche o outro processo "
            "antes de iniciar este Worker."
        )


async def claim_processing_key(key):
    async with PROCESSING_KEYS_LOCK:

        if key in PROCESSING_KEYS:
            return False

        PROCESSING_KEYS.add(
            key
        )

        return True


async def release_processing_key(key):
    async with PROCESSING_KEYS_LOCK:
        PROCESSING_KEYS.discard(
            key
        )


def normalize_text_for_fingerprint(text):
    text = text or ""
    return " ".join(text.split())


def media_signature(message):
    media = getattr(message, "media", None)

    if media is None:
        return "no-media"

    parts = [type(media).__name__]

    photo = getattr(media, "photo", None)
    if photo is not None:
        parts.append(f"photo:{getattr(photo, 'id', '')}")

    document = getattr(media, "document", None)
    if document is not None:
        parts.append(f"document:{getattr(document, 'id', '')}")

    webpage = getattr(media, "webpage", None)
    if webpage is not None:
        parts.append(f"webpage:{getattr(webpage, 'id', '')}")

    return "|".join(str(part) for part in parts)


def build_message_fingerprint(source_id, automation_id, message, grouped_id=None):
    normalized_text = normalize_text_for_fingerprint(
        getattr(message, "message", "")
    )

    signature = media_signature(message)

    raw = "|".join([
        str(automation_id),
        str(source_id),
        str(grouped_id if grouped_id is not None else getattr(message, "id", "")),
        normalized_text,
        signature
    ])

    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def build_album_fingerprint(source_id, automation_id, grouped_id, messages):
    components = []

    for message in messages:
        components.append(
            "|".join([
                str(getattr(message, "id", "")),
                normalize_text_for_fingerprint(getattr(message, "message", "")),
                media_signature(message)
            ])
        )

    raw = "|".join([
        str(automation_id),
        str(source_id),
        str(grouped_id),
        "||".join(components)
    ])

    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


async def claim_fingerprint(fingerprint):
    now = time.monotonic()

    async with FINGERPRINT_CACHE_LOCK:
        expired = [
            key
            for key, expires_at in FINGERPRINT_CACHE.items()
            if expires_at <= now
        ]

        for key in expired:
            FINGERPRINT_CACHE.pop(key, None)

        expires_at = FINGERPRINT_CACHE.get(fingerprint)

        if expires_at is not None and expires_at > now:
            return False

        FINGERPRINT_CACHE[fingerprint] = now + FINGERPRINT_TTL_SECONDS
        return True


# ============================================================
# ENDPOINTS
# ============================================================

AUTOMATIONS_ENDPOINT = (
    "/api/public/worker/automations"
)

LOGS_ENDPOINT = (
    "/api/public/worker/logs"
)

HEARTBEAT_ENDPOINT = (
    "/api/public/worker/heartbeat"
)

CHATS_SYNC_ENDPOINT = (
    "/api/public/worker/chats/sync"
)

MESSAGE_LINK_UPSERT_ENDPOINT = (
    "/api/public/worker/message-links/upsert"
)

MESSAGE_LINK_FIND_ENDPOINT = (
    "/api/public/worker/message-links/find"
)

MESSAGE_LINK_REMOVE_ENDPOINT = (
    "/api/public/worker/message-links/remove"
)


# ============================================================
# LOVABLE
# ============================================================

async def lovable_request(
    path,
    method="GET",
    data=None
):

    headers = {
        "x-worker-secret": WORKER_SECRET,
        "Content-Type": "application/json"
    }

    url = f"{LOVABLE_API_URL}{path}"

    async with httpx.AsyncClient(
        timeout=60
    ) as http:

        try:

            if method == "POST":

                response = await http.post(
                    url,
                    json=data,
                    headers=headers
                )

            elif method == "PUT":

                response = await http.put(
                    url,
                    json=data,
                    headers=headers
                )

            elif method == "DELETE":

                response = await http.delete(
                    url,
                    json=data,
                    headers=headers
                )

            else:

                response = await http.get(
                    url,
                    headers=headers
                )

            response.raise_for_status()

            if not response.content:
                return {}

            return response.json()

        except httpx.HTTPStatusError as error:

            print(
                f"[Lovable] HTTP "
                f"{error.response.status_code}"
            )

            print(
                "[Lovable] URL:",
                url
            )

            try:

                print(
                    "[Lovable] Resposta:",
                    error.response.text
                )

            except Exception:
                pass

            raise

        except httpx.RequestError as error:

            print(
                "[Lovable] Erro de conexão:",
                str(error)
            )

            raise


# ============================================================
# AUTOMAÇÕES
# ============================================================

async def load_automations():

    result = await lovable_request(
        AUTOMATIONS_ENDPOINT
    )

    return result.get(
        "automations",
        []
    )


def debug_automations(
    automations
):

    print(
        "\n================ DEBUG AUTOMAÇÕES ================"
    )

    print(
        "[DEBUG] Automações recebidas:",
        len(automations)
    )

    for index, automation in enumerate(
        automations,
        start=1
    ):

        replacements = (
            automation.get(
                "replacements",
                []
            )
            or []
        )

        blacklist = (
            automation.get(
                "blacklist",
                []
            )
            or []
        )

        print(
            f"\n[DEBUG] Automação #{index}"
        )

        print(
            "[DEBUG] ID:",
            automation.get("id")
        )

        print(
            "[DEBUG] Nome:",
            automation.get("name")
        )

        print(
            "[DEBUG] Source:",
            automation.get(
                "source_chat_id"
            )
        )

        print(
            "[DEBUG] Destination:",
            automation.get(
                "destination_chat_id"
            )
        )

        print(
            "[DEBUG] Replacements:",
            len(replacements)
        )

        print(
            "[DEBUG] Blacklist:",
            len(blacklist)
        )

    print(
        "\n===================================================\n"
    )


async def get_matching_automations(
    source_id
):

    automations = await load_automations()

    matches = []

    for automation in automations:

        source = automation.get(
            "source_chat_id"
        )

        if not source:
            continue

        if (
            str(source).strip()
            ==
            str(source_id).strip()
        ):

            matches.append(
                automation
            )

    return matches


# ============================================================
# HEARTBEAT
# ============================================================

async def send_heartbeat():

    me = await client.get_me()

    display_name = (
        f"{me.first_name or ''} "
        f"{me.last_name or ''}"
    ).strip()

    payload = {

        "worker_id":
            WORKER_ID,

        "telegram_user_id":
            str(me.id),

        "telegram_display_name":
            display_name,

        "telegram_username":
            me.username,

        "status":
            "online",

        "version":
            WORKER_VERSION
    }

    response = await lovable_request(
        HEARTBEAT_ENDPOINT,
        "POST",
        payload
    )

    print(
        "[Heartbeat] enviado."
    )

    if isinstance(
        response,
        dict
    ):

        account_id = response.get(
            "telegram_account_id"
        )

        if account_id:

            print(
                "[Heartbeat] Conta Lovable:",
                account_id
            )

    return response


async def heartbeat_loop():

    while True:

        try:

            await send_heartbeat()

        except Exception as error:

            print(
                "[Heartbeat] erro:",
                type(error).__name__,
                str(error)
            )

        await asyncio.sleep(
            HEARTBEAT_INTERVAL
        )


# ============================================================
# CHATS / ENTIDADES
# ============================================================

def get_chat_type(
    entity
):

    if isinstance(
        entity,
        Channel
    ):

        if getattr(
            entity,
            "megagroup",
            False
        ):

            return "supergroup"

        return "channel"

    if isinstance(
        entity,
        Chat
    ):

        return "group"

    return None


async def warm_entity_cache():

    print(
        "[Entities] Carregando entidades..."
    )

    count = 0

    async for dialog in client.iter_dialogs():

        ENTITY_CACHE[
            str(dialog.id)
        ] = dialog.input_entity

        count += 1

    print(
        f"[Entities] {count} entidades carregadas."
    )


async def resolve_destination_entity(
    destination_chat_id
):

    destination_str = str(
        destination_chat_id
    ).strip()

    cached = ENTITY_CACHE.get(
        destination_str
    )

    if cached is not None:

        return cached

    try:

        entity = await client.get_input_entity(
            int(destination_str)
        )

        ENTITY_CACHE[
            destination_str
        ] = entity

        return entity

    except Exception:
        pass

    async for dialog in client.iter_dialogs():

        dialog_id = str(
            dialog.id
        )

        ENTITY_CACHE[
            dialog_id
        ] = dialog.input_entity

        if dialog_id == destination_str:

            return dialog.input_entity

    raise ValueError(
        "Não foi possível resolver o chat "
        f"{destination_str}"
    )


async def sync_telegram_chats():

    print(
        "[Chats] Sincronizando..."
    )

    me = await client.get_me()

    chats = []

    async for dialog in client.iter_dialogs():

        entity = dialog.entity

        ENTITY_CACHE[
            str(dialog.id)
        ] = dialog.input_entity

        chat_type = get_chat_type(
            entity
        )

        if not chat_type:
            continue

        username = getattr(
            entity,
            "username",
            None
        )

        title = (
            dialog.name
            or getattr(
                entity,
                "title",
                None
            )
            or "Sem nome"
        )

        chats.append({

            "telegram_chat_id":
                str(dialog.id),

            "title":
                title,

            "username":
                username,

            "type":
                chat_type,

            "is_private":
                not bool(username)
        })

    response = await lovable_request(
        CHATS_SYNC_ENDPOINT,
        "POST",
        {
            "telegram_user_id":
                str(me.id),

            "chats":
                chats
        }
    )

    print(
        "[Chats] Sincronizados:",
        response.get(
            "synced",
            len(chats)
        )
    )

    return response


async def chat_sync_loop():

    while True:

        try:

            await sync_telegram_chats()

        except Exception as error:

            print(
                "[Chats] erro:",
                type(error).__name__,
                str(error)
            )

        await asyncio.sleep(
            CHAT_SYNC_INTERVAL
        )


# ============================================================
# MESSAGE LINKS
# ============================================================

def message_link_key(
    source_chat_id,
    source_message_id,
    automation_id
):

    return (
        f"{source_chat_id}:"
        f"{source_message_id}:"
        f"{automation_id}"
    )


async def save_message_link(
    automation_id,
    source_chat_id,
    source_message_id,
    destination_chat_id,
    destination_message_id,
    source_grouped_id=None
):

    link = {

        "automation_id":
            automation_id,

        "source_chat_id":
            str(source_chat_id),

        "source_message_id":
            int(source_message_id),

        "source_grouped_id":
            (
                str(source_grouped_id)
                if source_grouped_id
                else None
            ),

        "destination_chat_id":
            str(destination_chat_id),

        "destination_message_id":
            int(destination_message_id)
    }

    key = message_link_key(
        source_chat_id,
        source_message_id,
        automation_id
    )

    MESSAGE_LINK_CACHE[
        key
    ] = [link]

    print(
        "[Link] Registrado localmente:",
        source_message_id,
        "→",
        destination_message_id
    )

    try:

        await lovable_request(
            MESSAGE_LINK_UPSERT_ENDPOINT,
            "POST",
            link
        )

        print(
            "[Link] Persistido no Lovable."
        )

    except Exception as error:

        print(
            "[Link] Persistência remota falhou, "
            "cache local continua ativo:",
            type(error).__name__
        )


async def find_message_links(
    source_chat_id,
    source_message_id,
    automation_id=None
):

    local_links = []

    if automation_id:

        key = message_link_key(
            source_chat_id,
            source_message_id,
            automation_id
        )

        local_links = (
            MESSAGE_LINK_CACHE.get(
                key,
                []
            )
            or []
        )

    else:

        suffix = (
            f":{source_message_id}:"
        )

        for key, links in (
            MESSAGE_LINK_CACHE.items()
        ):

            if (
                key.startswith(
                    f"{source_chat_id}:"
                )
                and suffix in key
            ):

                local_links.extend(
                    links
                )

    if local_links:

        return local_links

    payload = {

        "source_chat_id":
            str(source_chat_id),

        "source_message_id":
            int(source_message_id)
    }

    if automation_id:

        payload[
            "automation_id"
        ] = automation_id

    try:

        response = await lovable_request(
            MESSAGE_LINK_FIND_ENDPOINT,
            "POST",
            payload
        )

        links = (
            response.get(
                "links",
                []
            )
            or []
        )

        for link in links:

            key = message_link_key(
                link["source_chat_id"],
                link["source_message_id"],
                link["automation_id"]
            )

            MESSAGE_LINK_CACHE[
                key
            ] = [link]

        return links

    except Exception as error:

        print(
            "[Link] Busca remota falhou:",
            type(error).__name__
        )

        return []


async def remove_message_links(
    source_chat_id,
    source_message_id,
    automation_id=None
):

    keys_to_remove = []

    for key in (
        MESSAGE_LINK_CACHE.keys()
    ):

        prefix = (
            f"{source_chat_id}:"
            f"{source_message_id}:"
        )

        if key.startswith(
            prefix
        ):

            if (
                automation_id is None
                or
                key.endswith(
                    f":{automation_id}"
                )
            ):

                keys_to_remove.append(
                    key
                )

    for key in keys_to_remove:

        MESSAGE_LINK_CACHE.pop(
            key,
            None
        )

    payload = {

        "source_chat_id":
            str(source_chat_id),

        "source_message_id":
            int(source_message_id)
    }

    if automation_id:

        payload[
            "automation_id"
        ] = automation_id

    try:

        await lovable_request(
            MESSAGE_LINK_REMOVE_ENDPOINT,
            "POST",
            payload
        )

    except Exception:

        pass


# ============================================================
# TEXTO RICO
# ============================================================

def utf16_length(
    text
):

    if not text:
        return 0

    return len(
        text.encode(
            "utf-16-le"
        )
    ) // 2


def get_active_replacements(
    automation
):

    replacements = (
        automation.get(
            "replacements",
            []
        )
        or []
    )

    replacements = [
        rule
        for rule
        in replacements

        if rule.get(
            "enabled",
            True
        )

        and rule.get(
            "match",
            ""
        )
    ]

    return sorted(
        replacements,
        key=lambda x:
            x.get(
                "priority",
                0
            )
    )


def replace_value(
    value,
    replacements
):

    if not value:
        return value

    result = value

    for rule in replacements:

        find = rule.get(
            "match",
            ""
        )

        replacement = rule.get(
            "replacement",
            ""
        )

        if not find:
            continue

        if rule.get(
            "case_sensitive",
            True
        ):

            result = result.replace(
                find,
                replacement
            )

        else:

            result = re.sub(
                re.escape(find),
                lambda _:
                    replacement,
                result,
                flags=re.IGNORECASE
            )

    return result


def find_replacement_occurrences(
    text,
    replacements
):

    occurrences = []
    working_text = text

    for rule in replacements:

        find = rule.get(
            "match",
            ""
        )

        replacement = rule.get(
            "replacement",
            ""
        )

        if not find:
            continue

        flags = (
            0
            if rule.get(
                "case_sensitive",
                True
            )
            else re.IGNORECASE
        )

        pattern = re.compile(
            re.escape(find),
            flags
        )

        while True:

            match = pattern.search(
                working_text
            )

            if not match:
                break

            start = match.start()
            end = match.end()

            before = working_text[
                :start
            ]

            old_value = working_text[
                start:end
            ]

            occurrences.append({

                "start":
                    utf16_length(
                        before
                    ),

                "old_length":
                    utf16_length(
                        old_value
                    ),

                "new_length":
                    utf16_length(
                        replacement
                    )
            })

            working_text = (
                working_text[:start]
                +
                replacement
                +
                working_text[end:]
            )

    return (
        working_text,
        occurrences
    )


def adjust_entities_for_replacements(
    entities,
    occurrences
):

    if not entities:
        return []

    result = copy.deepcopy(
        entities
    )

    for occurrence in occurrences:

        replace_start = (
            occurrence["start"]
        )

        old_length = (
            occurrence[
                "old_length"
            ]
        )

        new_length = (
            occurrence[
                "new_length"
            ]
        )

        replace_end = (
            replace_start
            +
            old_length
        )

        delta = (
            new_length
            -
            old_length
        )

        for entity in result:

            entity_start = (
                entity.offset
            )

            entity_end = (
                entity.offset
                +
                entity.length
            )

            if (
                replace_end
                <= entity_start
            ):

                entity.offset += delta

            elif (
                replace_start
                < entity_end
                and
                replace_end
                > entity_start
            ):

                entity.length = max(
                    0,
                    entity.length
                    +
                    delta
                )

    return [
        entity
        for entity in result

        if getattr(
            entity,
            "length",
            0
        ) > 0
    ]


def process_hidden_urls(
    entities,
    replacements
):

    result = copy.deepcopy(
        entities
        or []
    )

    for entity in result:

        if isinstance(
            entity,
            MessageEntityTextUrl
        ):

            entity.url = (
                replace_value(
                    entity.url or "",
                    replacements
                )
            )

    return result


def check_blacklist(
    text,
    entities,
    automation
):

    blacklist = (
        automation.get(
            "blacklist",
            []
        )
        or []
    )

    hidden_urls = []

    for entity in (
        entities or []
    ):

        if isinstance(
            entity,
            MessageEntityTextUrl
        ):

            if entity.url:

                hidden_urls.append(
                    entity.url
                )

    content = (
        (text or "")
        +
        "\n"
        +
        "\n".join(
            hidden_urls
        )
    )

    for rule in blacklist:

        if not rule.get(
            "enabled",
            True
        ):

            continue

        term = rule.get(
            "term",
            ""
        )

        if not term:
            continue

        match_type = rule.get(
            "match_type",
            "contains"
        )

        detected = False

        if match_type == "contains":

            detected = (
                term.lower()
                in
                content.lower()
            )

        elif match_type == "exact":

            detected = (
                content.lower().strip()
                ==
                term.lower().strip()
            )

        elif match_type == "regex":

            try:

                detected = bool(
                    re.search(
                        term,
                        content,
                        flags=re.IGNORECASE
                    )
                )

            except re.error:

                continue

        if (
            detected
            and
            rule.get(
                "action",
                "block"
            )
            ==
            "block"
        ):

            return True

    return False


def process_rich_text(
    text,
    entities,
    automation
):

    text = text or ""

    entities = copy.deepcopy(
        entities
        or []
    )

    if check_blacklist(
        text,
        entities,
        automation
    ):

        return None, []

    replacements = (
        get_active_replacements(
            automation
        )
    )

    entities = process_hidden_urls(
        entities,
        replacements
    )

    (
        processed_text,
        occurrences
    ) = find_replacement_occurrences(
        text,
        replacements
    )

    processed_entities = (
        adjust_entities_for_replacements(
            entities,
            occurrences
        )
    )

    return (
        processed_text,
        processed_entities
    )


# ============================================================
# LOGS
# ============================================================

async def send_log(
    automation_id,
    source_message_id,
    status,
    original_text="",
    processed_text="",
    destination_message_id=None,
    blocked_reason=None,
    error_message=None
):

    payload = {

        "automation_id":
            automation_id,

        # O endpoint do Lovable espera STRING.
        "source_message_id":
            (
                str(source_message_id)
                if source_message_id is not None
                else None
            ),

        # O endpoint do Lovable espera STRING ou null.
        "destination_message_id":
            (
                str(destination_message_id)
                if destination_message_id is not None
                else None
            ),

        "original_text":
            original_text,

        "processed_text":
            processed_text,

        "status":
            status,

        "blocked_reason":
            blocked_reason,

        "error_message":
            error_message
    }

    try:

        await lovable_request(
            LOGS_ENDPOINT,
            "POST",
            payload
        )

    except Exception as error:

        print(
            "[Logs] Falha:",
            str(error)
        )


# ============================================================
# PUBLICAR MENSAGEM NORMAL
# ============================================================

async def publish_single_message(
    message,
    source_id,
    automation
):

    automation_id = automation["id"]

    processing_key = (
        f"single:"
        f"{source_id}:"
        f"{message.id}:"
        f"{automation_id}"
    )

    claimed = await claim_processing_key(
        processing_key
    )

    if not claimed:

        print(
            "[Duplicate] Mensagem já está sendo processada:",
            message.id
        )

        return

    fingerprint = build_message_fingerprint(
        source_id=source_id,
        automation_id=automation_id,
        message=message
    )

    fingerprint_claimed = await claim_fingerprint(fingerprint)

    if not fingerprint_claimed:
        print(
            "[Duplicate Guard] Fingerprint repetido ignorado:",
            fingerprint[:12],
            "| message_id:",
            message.id
        )
        await release_processing_key(processing_key)
        return

    started_at = time.monotonic()

    try:

        # ----------------------------------------------------
        # IDEMPOTÊNCIA
        #
        # Se já existe vínculo source -> destination,
        # esta mensagem já foi publicada antes.
        # ----------------------------------------------------

        existing_links = await find_message_links(

            source_chat_id=
                source_id,

            source_message_id=
                message.id,

            automation_id=
                automation_id
        )

        if existing_links:

            print(
                "[Duplicate] Mensagem já publicada. Ignorando:",
                message.id
            )

            return


        original_text = (
            message.message
            or ""
        )

        (
            processed_text,
            processed_entities
        ) = process_rich_text(

            original_text,
            message.entities or [],
            automation
        )

        if processed_text is None:

            print(
                "[Blacklist] Bloqueada."
            )

            await send_log(

                automation_id=
                    automation_id,

                source_message_id=
                    message.id,

                status="blocked",

                original_text=
                    original_text,

                blocked_reason=
                    "blacklist"
            )

            return


        destination = automation.get(
            "destination_chat_id"
        )

        if not destination:
            return


        if (
            str(destination).strip()
            ==
            str(source_id).strip()
        ):

            return


        destination_entity = (
            await resolve_destination_entity(
                destination
            )
        )


        preserve_media = automation.get(
            "preserve_media",
            True
        )

        preserve_caption = automation.get(
            "preserve_caption",
            True
        )

        preserve_formatting = (
            automation.get(
                "preserve_formatting",
                True
            )
        )

        formatting_entities = (
            processed_entities
            if preserve_formatting
            else []
        )


        try:

            # ------------------------------------------------
            # MÍDIA
            # ------------------------------------------------

            if (
                message.media
                and
                preserve_media
            ):

                print(
                    "[Media] Iniciando envio:",
                    message.id
                )

                sent = await client.send_file(

                    destination_entity,

                    message.media,

                    caption=(
                        processed_text
                        if preserve_caption
                        else ""
                    ),

                    formatting_entities=(
                        formatting_entities
                        if preserve_caption
                        else []
                    )
                )


            # ------------------------------------------------
            # TEXTO
            # ------------------------------------------------

            else:

                if not processed_text:
                    return

                sent = await client.send_message(

                    destination_entity,

                    processed_text,

                    formatting_entities=
                        formatting_entities
                )


        except ChatForwardsRestrictedError:

            # IMPORTANTE:
            # O Telegram marcou o chat de origem como protegido
            # contra encaminhamento/cópia de mídia.
            #
            # Não tentamos baixar/reupar a mídia para contornar
            # essa proteção. Também não fazemos retry, porque
            # isso pode gerar processamento repetido/duplicado.

            print(
                "[Protected Chat] Telegram bloqueou o envio "
                "desta mídia por proteção do canal de origem. "
                "Mensagem ignorada sem retry."
            )

            await send_log(

                automation_id=
                    automation_id,

                source_message_id=
                    message.id,

                status="error",

                original_text=
                    original_text,

                processed_text=
                    processed_text,

                error_message=(
                    "ChatForwardsRestrictedError: "
                    "mídia protegida pelo canal de origem"
                )
            )

            return


        elapsed = (
            time.monotonic()
            -
            started_at
        )

        print(
            "[Publish] Publicada:",
            message.id,
            "→",
            sent.id,
            f"({elapsed:.2f}s)"
        )


        # ----------------------------------------------------
        # PERSISTIR VÍNCULO ANTES DE ENCERRAR O HANDLER
        # ----------------------------------------------------

        await save_message_link(

            automation_id=
                automation_id,

            source_chat_id=
                source_id,

            source_message_id=
                message.id,

            destination_chat_id=
                destination,

            destination_message_id=
                sent.id
        )


        await send_log(

            automation_id=
                automation_id,

            source_message_id=
                message.id,

            destination_message_id=
                sent.id,

            status="published",

            original_text=
                original_text,

            processed_text=
                processed_text
        )


    finally:

        await release_processing_key(
            processing_key
        )


# ============================================================
# NOVA MENSAGEM
# ============================================================

@client.on(
    events.NewMessage
)
async def new_message_handler(
    event
):

    # Ignora mensagens enviadas pela própria conta conectada.
    if getattr(event, "out", False):
        print("[Own Message] Evento de saída ignorado.")
        return

    message = event.message

    # Álbum é tratado separadamente.
    if getattr(
        message,
        "grouped_id",
        None
    ):

        return

    source_id = event.chat_id

    matches = (
        await get_matching_automations(
            source_id
        )
    )

    if not matches:
        return

    for automation in matches:

        try:

            await publish_single_message(
                message,
                source_id,
                automation
            )

        except Exception as error:

            print(
                "[NewMessage] ERRO:",
                type(error).__name__,
                str(error)
            )


# ============================================================
# ÁLBUM
# ============================================================

@client.on(
    events.Album
)
async def album_handler(
    event
):

    # Ignora álbuns enviados pela própria conta conectada.
    if getattr(event, "out", False):
        print("[Own Album] Evento de saída ignorado.")
        return

    source_id = event.chat_id

    matches = (
        await get_matching_automations(
            source_id
        )
    )

    if not matches:
        return


    media_messages = [
        message
        for message
        in event.messages
        if message.media
    ]

    if not media_messages:
        return


    caption_index = 0
    caption_message = (
        media_messages[0]
    )


    for index, message in enumerate(
        media_messages
    ):

        if (
            message.message
            and
            message.message.strip()
        ):

            caption_index = index
            caption_message = message
            break


    original_caption = (
        caption_message.message
        or ""
    )

    original_entities = (
        caption_message.entities
        or []
    )

    medias = [
        message.media
        for message
        in media_messages
    ]


    for automation in matches:

        automation_id = automation["id"]

        processing_key = (
            f"album:"
            f"{source_id}:"
            f"{event.grouped_id}:"
            f"{automation_id}"
        )

        claimed = await claim_processing_key(
            processing_key
        )

        if not claimed:

            print(
                "[Duplicate] Álbum já está sendo processado:",
                event.grouped_id
            )

            continue

        fingerprint = build_album_fingerprint(
            source_id=source_id,
            automation_id=automation_id,
            grouped_id=event.grouped_id,
            messages=media_messages
        )

        fingerprint_claimed = await claim_fingerprint(fingerprint)

        if not fingerprint_claimed:
            print(
                "[Duplicate Guard] Álbum repetido ignorado:",
                fingerprint[:12],
                "| grouped_id:",
                event.grouped_id
            )
            await release_processing_key(processing_key)
            continue

        started_at = time.monotonic()

        try:

            # ------------------------------------------------
            # IDEMPOTÊNCIA DO ÁLBUM
            #
            # Se qualquer item principal já estiver vinculado,
            # tratamos o álbum como já publicado.
            # ------------------------------------------------

            existing_links = await find_message_links(

                source_chat_id=
                    source_id,

                source_message_id=
                    caption_message.id,

                automation_id=
                    automation_id
            )

            if existing_links:

                print(
                    "[Duplicate] Álbum já publicado. Ignorando:",
                    event.grouped_id
                )

                continue


            (
                processed_caption,
                processed_entities
            ) = process_rich_text(

                original_caption,
                original_entities,
                automation
            )


            if processed_caption is None:

                print(
                    "[Blacklist] Álbum bloqueado."
                )

                await send_log(

                    automation_id=
                        automation_id,

                    source_message_id=
                        caption_message.id,

                    status="blocked",

                    original_text=
                        original_caption,

                    blocked_reason=
                        "blacklist"
                )

                continue


            destination = (
                automation.get(
                    "destination_chat_id"
                )
            )

            if not destination:
                continue


            if (
                str(destination).strip()
                ==
                str(source_id).strip()
            ):

                continue


            destination_entity = (
                await resolve_destination_entity(
                    destination
                )
            )


            preserve_media = (
                automation.get(
                    "preserve_media",
                    True
                )
            )

            preserve_caption = (
                automation.get(
                    "preserve_caption",
                    True
                )
            )

            preserve_formatting = (
                automation.get(
                    "preserve_formatting",
                    True
                )
            )


            # ------------------------------------------------
            # NÃO PRESERVAR MÍDIA
            # ------------------------------------------------

            if not preserve_media:

                if not processed_caption:
                    continue

                sent = await client.send_message(

                    destination_entity,

                    processed_caption,

                    formatting_entities=(
                        processed_entities
                        if preserve_formatting
                        else []
                    )
                )


                await save_message_link(

                    automation_id=
                        automation_id,

                    source_chat_id=
                        source_id,

                    source_message_id=
                        caption_message.id,

                    source_grouped_id=
                        event.grouped_id,

                    destination_chat_id=
                        destination,

                    destination_message_id=
                        sent.id
                )

                continue


            captions = [
                ""
                for _
                in media_messages
            ]

            album_entities = [
                []
                for _
                in media_messages
            ]


            if preserve_caption:

                captions[
                    caption_index
                ] = processed_caption

                if preserve_formatting:

                    album_entities[
                        caption_index
                    ] = processed_entities


            try:

                print(
                    "[Album] Enviando:",
                    event.grouped_id,
                    "| mídias:",
                    len(medias)
                )

                sent_messages = (
                    await client.send_file(

                        destination_entity,

                        medias,

                        caption=
                            captions,

                        formatting_entities=
                            album_entities
                    )
                )


            except ChatForwardsRestrictedError:

                print(
                    "[Protected Chat] Telegram bloqueou "
                    "o álbum por proteção do canal de origem. "
                    "Álbum ignorado sem retry."
                )

                await send_log(

                    automation_id=
                        automation_id,

                    source_message_id=
                        caption_message.id,

                    status="error",

                    original_text=
                        original_caption,

                    processed_text=
                        processed_caption,

                    error_message=(
                        "ChatForwardsRestrictedError: "
                        "álbum protegido pelo canal de origem"
                    )
                )

                continue


            if not isinstance(
                sent_messages,
                list
            ):

                sent_messages = [
                    sent_messages
                ]


            elapsed = (
                time.monotonic()
                -
                started_at
            )

            print(
                "[Album] Publicado:",
                len(sent_messages),
                "itens",
                f"({elapsed:.2f}s)"
            )


            # ------------------------------------------------
            # VINCULAR CADA ITEM
            # ------------------------------------------------

            for (
                source_message,
                destination_message
            ) in zip(
                media_messages,
                sent_messages
            ):

                await save_message_link(

                    automation_id=
                        automation_id,

                    source_chat_id=
                        source_id,

                    source_message_id=
                        source_message.id,

                    source_grouped_id=
                        event.grouped_id,

                    destination_chat_id=
                        destination,

                    destination_message_id=
                        destination_message.id
                )


            await send_log(

                automation_id=
                    automation_id,

                source_message_id=
                    caption_message.id,

                destination_message_id=(
                    sent_messages[0].id
                    if sent_messages
                    else None
                ),

                status="published",

                original_text=
                    original_caption,

                processed_text=
                    processed_caption
            )


        finally:

            await release_processing_key(
                processing_key
            )


# ============================================================
# EDITAR MENSAGEM
# ============================================================

@client.on(
    events.MessageEdited
)
async def edited_message_handler(
    event
):

    source_id = event.chat_id
    message = event.message

    if source_id is None:
        return

    matches = (
        await get_matching_automations(
            source_id
        )
    )

    if not matches:
        return

    print(
        "[Edit] Mensagem editada:",
        source_id,
        message.id
    )

    for automation in matches:

        links = await find_message_links(

            source_chat_id=
                source_id,

            source_message_id=
                message.id,

            automation_id=
                automation["id"]
        )

        if not links:

            print(
                "[Edit] Nenhum vínculo encontrado "
                "para a mensagem."
            )

            continue

        (
            processed_text,
            processed_entities
        ) = process_rich_text(

            message.message or "",

            message.entities or [],

            automation
        )

        # Se edição passou a bater
        # na blacklist, apagar destino.

        if processed_text is None:

            for link in links:

                try:

                    destination_entity = (
                        await resolve_destination_entity(
                            link[
                                "destination_chat_id"
                            ]
                        )
                    )

                    await client.delete_messages(

                        destination_entity,

                        [
                            int(
                                link[
                                    "destination_message_id"
                                ]
                            )
                        ],

                        revoke=True
                    )

                except Exception as error:

                    print(
                        "[Edit] Erro apagando "
                        "mensagem bloqueada:",
                        str(error)
                    )

            continue

        preserve_caption = (
            automation.get(
                "preserve_caption",
                True
            )
        )

        preserve_formatting = (
            automation.get(
                "preserve_formatting",
                True
            )
        )

        # Se for mídia e preserve_caption=False,
        # não existe legenda espelhada para editar.

        if (
            message.media
            and
            not preserve_caption
        ):

            continue

        for link in links:

            try:

                destination_entity = (
                    await resolve_destination_entity(
                        link[
                            "destination_chat_id"
                        ]
                    )
                )

                destination_message_id = int(
                    link[
                        "destination_message_id"
                    ]
                )

                await client.edit_message(

                    destination_entity,

                    destination_message_id,

                    processed_text,

                    formatting_entities=(
                        processed_entities
                        if preserve_formatting
                        else []
                    )
                )

                print(
                    "[Edit] Atualizada:",
                    message.id,
                    "→",
                    destination_message_id
                )

                await send_log(

                    automation_id=
                        automation["id"],

                    source_message_id=
                        message.id,

                    destination_message_id=
                        destination_message_id,

                    status="edited",

                    original_text=
                        message.message or "",

                    processed_text=
                        processed_text
                )

            except Exception as error:

                print(
                    "[Edit] ERRO:",
                    type(error).__name__,
                    str(error)
                )


# ============================================================
# EXCLUIR MENSAGEM
# ============================================================

@client.on(
    events.MessageDeleted
)
async def deleted_message_handler(
    event
):

    source_id = event.chat_id

    print(
        "[Delete] Evento recebido. Chat:",
        source_id,
        "IDs:",
        event.deleted_ids
    )

    # Em canais/supergrupos normalmente
    # temos chat_id.
    #
    # Se vier None, não vamos apagar no
    # escuro para evitar excluir mensagem
    # errada em outro chat.

    if source_id is None:

        print(
            "[Delete] chat_id ausente. "
            "Exclusão ignorada por segurança."
        )

        return

    for source_message_id in (
        event.deleted_ids
    ):

        links = await find_message_links(

            source_chat_id=
                source_id,

            source_message_id=
                source_message_id
        )

        if not links:

            print(
                "[Delete] Nenhum vínculo:",
                source_message_id
            )

            continue

        # Agrupar por destino.

        grouped_destinations = (
            defaultdict(list)
        )

        for link in links:

            grouped_destinations[
                str(
                    link[
                        "destination_chat_id"
                    ]
                )
            ].append(
                int(
                    link[
                        "destination_message_id"
                    ]
                )
            )

        for (
            destination_chat_id,
            destination_ids
        ) in grouped_destinations.items():

            try:

                destination_entity = (
                    await resolve_destination_entity(
                        destination_chat_id
                    )
                )

                await client.delete_messages(

                    destination_entity,

                    destination_ids,

                    revoke=True
                )

                print(
                    "[Delete] Excluída(s) no destino:",
                    destination_ids
                )

            except Exception as error:

                print(
                    "[Delete] ERRO:",
                    type(error).__name__,
                    str(error)
                )

        for link in links:

            await send_log(

                automation_id=
                    link[
                        "automation_id"
                    ],

                source_message_id=
                    source_message_id,

                destination_message_id=
                    link[
                        "destination_message_id"
                    ],

                status="deleted"
            )

        await remove_message_links(

            source_chat_id=
                source_id,

            source_message_id=
                source_message_id
        )


# ============================================================
# MAIN
# ============================================================

async def main():

    print(
        "================================="
    )

    print(
        " TELEGRAM WORKER"
    )

    print(
        f" VERSION {WORKER_VERSION}"
    )

    print(
        "================================="
    )

    print(
        "[Worker] Conectando..."
    )

    # Impede que duas instâncias locais do mesmo Worker
    # publiquem a mesma mensagem em duplicidade.
    acquire_process_lock()

    await client.start()

    me = await client.get_me()

    print(
        "[Telegram] Conectado!"
    )

    print(
        "[Telegram] ID:",
        me.id
    )

    print(
        "[Telegram] Nome:",
        me.first_name
    )

    if me.username:

        print(
            "[Telegram] Username:",
            f"@{me.username}"
        )

    await warm_entity_cache()

    print(
        "[Lovable] Testando..."
    )

    try:

        automations = (
            await load_automations()
        )

        print(
            "[Lovable] Conectado!"
        )

        print(
            "[Lovable] Automações ativas:",
            len(automations)
        )

        debug_automations(
            automations
        )

    except Exception as error:

        print(
            "[Lovable] ERRO:",
            type(error).__name__,
            str(error)
        )

    try:

        await send_heartbeat()

    except Exception as error:

        print(
            "[Heartbeat] inicial falhou:",
            str(error)
        )

    try:

        await sync_telegram_chats()

    except Exception as error:

        print(
            "[Chats] sync inicial falhou:",
            str(error)
        )

    asyncio.create_task(
        heartbeat_loop()
    )

    asyncio.create_task(
        chat_sync_loop()
    )

    print(
        "================================="
    )

    print(
        "[Worker] ONLINE"
    )

    print(
        "[Worker] Álbuns: ATIVO"
    )

    print(
        "[Worker] Formatação: ATIVO"
    )

    print(
        "[Worker] Hyperlink replace: ATIVO"
    )

    print(
        "[Worker] Edição sincronizada: ATIVO"
    )

    print(
        "[Worker] Exclusão sincronizada: ATIVO"
    )

    print(
        "[Worker] Anti-duplicação: ATIVO"
    )

    print(
        "[Worker] Dedupe por fingerprint: ATIVO"
    )

    print(
        "[Worker] Own-message guard: ATIVO"
    )

    print(
        "[Worker] Proteção de mídia restrita: ATIVO"
    )

    print(
        "================================="
    )

    await client.run_until_disconnected()


if __name__ == "__main__":

    asyncio.run(
        main()
    )